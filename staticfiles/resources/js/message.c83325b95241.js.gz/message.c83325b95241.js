
 setTimeout(function(){
        if( $('#message').length >0) {
            $('#message').remove();
        }
    }, 3000);